const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./server/config/db');
const path = require('path');

// Lade Umgebungsvariablen
dotenv.config();

// Verbinde zur Datenbank
connectDB();

const app = express();

// Body Parser
app.use(express.json());

// CORS aktivieren
app.use(cors());

// API-Routen
app.use('/api/auth', require('./server/routes/auth'));
app.use('/api/categories', require('./server/routes/categories'));
// Weitere Routen hier hinzufügen

// Statische Dateien im Produktionsmodus bereitstellen
if (process.env.NODE_ENV === 'production') {
  app.use(express.static('client/dist'));

  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'client', 'dist', 'index.html'));
  });
}

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Server läuft auf Port ${PORT}`));
