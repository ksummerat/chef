const mongoose = require('mongoose');

const RecipeSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Bitte geben Sie einen Titel ein'],
    trim: true,
    maxlength: [100, 'Titel darf nicht länger als 100 Zeichen sein']
  },
  description: {
    type: String,
    required: [true, 'Bitte geben Sie eine Beschreibung ein'],
    maxlength: [500, 'Beschreibung darf nicht länger als 500 Zeichen sein']
  },
  ingredients: {
    type: [String],
    required: [true, 'Bitte geben Sie Zutaten ein']
  },
  instructions: {
    type: [String],
    required: [true, 'Bitte geben Sie Zubereitungsschritte ein']
  },
  prepTime: {
    type: Number,
    required: [true, 'Bitte geben Sie die Zubereitungszeit ein']
  },
  cookTime: {
    type: Number,
    required: [true, 'Bitte geben Sie die Kochzeit ein']
  },
  servings: {
    type: Number,
    required: [true, 'Bitte geben Sie die Anzahl der Portionen ein']
  },
  difficulty: {
    type: String,
    required: [true, 'Bitte geben Sie den Schwierigkeitsgrad ein'],
    enum: ['Einfach', 'Mittel', 'Schwer']
  },
  images: {
    type: [String],
    required: [true, 'Bitte fügen Sie mindestens ein Bild hinzu']
  },
  categories: [{
    type: mongoose.Schema.ObjectId,
    ref: 'Category',
    required: true
  }],
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  ratings: [
    {
      rating: {
        type: Number,
        min: 1,
        max: 5,
        required: true
      },
      comment: {
        type: String,
        required: true
      },
      user: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: true
      },
      createdAt: {
        type: Date,
        default: Date.now
      }
    }
  ],
  averageRating: {
    type: Number,
    min: [1, 'Bewertung muss mindestens 1 sein'],
    max: [5, 'Bewertung kann höchstens 5 sein']
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Durchschnittliche Bewertung berechnen
RecipeSchema.methods.getAverageRating = function() {
  if (this.ratings.length === 0) return 0;
  
  const sum = this.ratings.reduce((total, rating) => total + rating.rating, 0);
  return sum / this.ratings.length;
};

module.exports = mongoose.model('Recipe', RecipeSchema);
