import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import AdminLayout from './components/layout/AdminLayout';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/admin/Dashboard';
import Categories from './pages/admin/Categories';
import BlogPosts from './pages/admin/BlogPosts';
import Users from './pages/admin/Users';
import ProtectedRoute from './components/ProtectedRoute';
import AdminRoute from './components/AdminRoute';

function App() {
  return (
    <Routes>
      {/* Öffentliche Routen */}
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="login" element={<Login />} />
        <Route path="registrieren" element={<Register />} />
      </Route>

      {/* Admin-Routen */}
      <Route 
        path="/admin" 
        element={
          <ProtectedRoute>
            <AdminRoute>
              <AdminLayout />
            </AdminRoute>
          </ProtectedRoute>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="kategorien" element={<Categories />} />
        <Route path="blog" element={<BlogPosts />} />
        <Route path="benutzer" element={<Users />} />
      </Route>
    </Routes>
  );
}

export default App;
