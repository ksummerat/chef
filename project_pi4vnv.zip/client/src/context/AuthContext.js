import React, { createContext, useState, useContext, useEffect } from 'react';
import axios from 'axios';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Axios-Instanz mit Auth-Header
  const authAxios = axios.create({
    baseURL: '/api'
  });

  // Auth-Header für jede Anfrage hinzufügen
  authAxios.interceptors.request.use(
    (config) => {
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error) => {
      return Promise.reject(error);
    }
  );

  // Benutzer laden
  useEffect(() => {
    const loadUser = async () => {
      if (token) {
        try {
          const res = await authAxios.get('/auth/me');
          setUser(res.data.data);
          setIsAuthenticated(true);
        } catch (err) {
          localStorage.removeItem('token');
          setToken(null);
          setUser(null);
          setIsAuthenticated(false);
          setError('Sitzung abgelaufen. Bitte melden Sie sich erneut an.');
        }
      }
      setLoading(false);
    };

    loadUser();
  }, [token]);

  // Registrieren
  const register = async (userData) => {
    try {
      const res = await axios.post('/api/auth/register', userData);
      localStorage.setItem('token', res.data.token);
      setToken(res.data.token);
      setUser(res.data.user);
      setIsAuthenticated(true);
      setError(null);
      return res.data;
    } catch (err) {
      setError(
        err.response?.data?.message || 'Registrierung fehlgeschlagen. Bitte versuchen Sie es erneut.'
      );
      throw err;
    }
  };

  // Anmelden
  const login = async (userData) => {
    try {
      const res = await axios.post('/api/auth/login', userData);
      localStorage.setItem('token', res.data.token);
      setToken(res.data.token);
      setUser(res.data.user);
      setIsAuthenticated(true);
      setError(null);
      return res.data;
    } catch (err) {
      setError(
        err.response?.data?.message || 'Anmeldung fehlgeschlagen. Bitte überprüfen Sie Ihre Anmeldedaten.'
      );
      throw err;
    }
  };

  // Abmelden
  const logout = async () => {
    try {
      await authAxios.get('/auth/logout');
    } catch (err) {
      console.error('Fehler beim Abmelden:', err);
    } finally {
      localStorage.removeItem('token');
      setToken(null);
      setUser(null);
      setIsAuthenticated(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated,
        loading,
        error,
        register,
        login,
        logout,
        authAxios
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
