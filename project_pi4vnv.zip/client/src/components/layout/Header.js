import React from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { FiMenu, FiX, FiUser, FiLogOut } from 'react-icons/fi';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [isProfileOpen, setIsProfileOpen] = React.useState(false);
  const { isAuthenticated, user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleProfile = () => {
    setIsProfileOpen(!isProfileOpen);
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className="text-xl font-bold text-primary-600">Rezept App</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <NavLink 
              to="/" 
              className={({ isActive }) => 
                isActive 
                  ? 'text-primary-600 font-medium' 
                  : 'text-gray-600 hover:text-primary-600'
              }
              end
            >
              Startseite
            </NavLink>
            <NavLink 
              to="/rezepte" 
              className={({ isActive }) => 
                isActive 
                  ? 'text-primary-600 font-medium' 
                  : 'text-gray-600 hover:text-primary-600'
              }
            >
              Rezepte
            </NavLink>
            <NavLink 
              to="/kategorien" 
              className={({ isActive }) => 
                isActive 
                  ? 'text-primary-600 font-medium' 
                  : 'text-gray-600 hover:text-primary-600'
              }
            >
              Kategorien
            </NavLink>
          </nav>

          {/* User Menu (Desktop) */}
          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={toggleProfile}
                  className="flex items-center space-x-2 text-gray-700 hover:text-primary-600 focus:outline-none"
                >
                  <FiUser className="w-5 h-5" />
                  <span>{user?.name}</span>
                </button>
                {isProfileOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
                    {user?.role === 'admin' && (
                      <Link
                        to="/admin"
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        Admin-Bereich
                      </Link>
                    )}
                    <Link
                      to="/profil"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Mein Profil
                    </Link>
                    <Link
                      to="/meine-rezepte"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Meine Rezepte
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Abmelden
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link to="/login" className="text-gray-600 hover:text-primary-600">
                  Anmelden
                </Link>
                <Link to="/registrieren" className="btn btn-primary">
                  Registrieren
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="md:hidden text-gray-600 hover:text-primary-600 focus:outline-none"
          >
            {isMenuOpen ? <FiX className="w-6 h-6" /> : <FiMenu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200 py-2">
          <div className="container mx-auto px-4">
            <nav className="flex flex-col space-y-3 py-3">
              <NavLink 
                to="/" 
                className={({ isActive }) => 
                  isActive 
                    ? 'text-primary-600 font-medium' 
                    : 'text-gray-600 hover:text-primary-600'
                }
                end
                onClick={() => setIsMenuOpen(false)}
              >
                Startseite
              </NavLink>
              <NavLink 
                to="/rezepte" 
                className={({ isActive }) => 
                  isActive 
                    ? 'text-primary-600 font-medium' 
                    : 'text-gray-600 hover:text-primary-600'
                }
                onClick={() => setIsMenuOpen(false)}
              >
                Rezepte
              </NavLink>
              <NavLink 
                to="/kategorien" 
                className={({ isActive }) => 
                  isActive 
                    ? 'text-primary-600 font-medium' 
                    : 'text-gray-600 hover:text-primary-600'
                }
                onClick={() => setIsMenuOpen(false)}
              >
                Kategorien
              </NavLink>
              
              {isAuthenticated ? (
                <>
                  <hr className="border-gray-200" />
                  {user?.role === 'admin' && (
                    <Link
                      to="/admin"
                      className="text-gray-600 hover:text-primary-600"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Admin-Bereich
                    </Link>
                  )}
                  <Link
                    to="/profil"
                    className="text-gray-600 hover:text-primary-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Mein Profil
                  </Link>
                  <Link
                    to="/meine-rezepte"
                    className="text-gray-600 hover:text-primary-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Meine Rezepte
                  </Link>
                  <button
                    onClick={() => {
                      handleLogout();
                      setIsMenuOpen(false);
                    }}
                    className="flex items-center text-gray-600 hover:text-primary-600"
                  >
                    <FiLogOut className="mr-2" />
                    Abmelden
                  </button>
                </>
              ) : (
                <>
                  <hr className="border-gray-200" />
                  <Link 
                    to="/login" 
                    className="text-gray-600 hover:text-primary-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Anmelden
                  </Link>
                  <Link 
                    to="/registrieren" 
                    className="text-gray-600 hover:text-primary-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Registrieren
                  </Link>
                </>
              )}
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
