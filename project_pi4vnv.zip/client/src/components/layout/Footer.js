import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Rezept App</h3>
            <p className="text-gray-300">
              Entdecken Sie köstliche Rezepte und teilen Sie Ihre eigenen kulinarischen Kreationen mit unserer Community.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-white">
                  Startseite
                </Link>
              </li>
              <li>
                <Link to="/rezepte" className="text-gray-300 hover:text-white">
                  Rezepte
                </Link>
              </li>
              <li>
                <Link to="/kategorien" className="text-gray-300 hover:text-white">
                  Kategorien
                </Link>
              </li>
              <li>
                <Link to="/registrieren" className="text-gray-300 hover:text-white">
                  Registrieren
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Kontakt</h3>
            <p className="text-gray-300 mb-2">
              Haben Sie Fragen oder Anregungen? Kontaktieren Sie uns!
            </p>
            <a
              href="mailto:info@rezept-app.de"
              className="text-primary-400 hover:text-primary-300"
            >
              info@rezept-app.de
            </a>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-400">
          <p>&copy; {currentYear} Rezept App. Alle Rechte vorbehalten.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
