import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  FiHome, 
  FiList, 
  FiFileText, 
  FiUsers, 
  FiSettings,
  FiTag
} from 'react-icons/fi';

const AdminSidebar = () => {
  return (
    <aside className="bg-gray-900 text-gray-300 w-64 min-h-screen hidden lg:block">
      <nav className="p-4">
        <ul className="space-y-2">
          <li>
            <NavLink
              to="/admin"
              end
              className={({ isActive }) =>
                `flex items-center p-3 rounded-md ${
                  isActive
                    ? 'bg-gray-800 text-white'
                    : 'hover:bg-gray-800 hover:text-white'
                }`
              }
            >
              <FiHome className="mr-3" />
              Dashboard
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/admin/rezepte"
              className={({ isActive }) =>
                `flex items-center p-3 rounded-md ${
                  isActive
                    ? 'bg-gray-800 text-white'
                    : 'hover:bg-gray-800 hover:text-white'
                }`
              }
            >
              <FiList className="mr-3" />
              Rezepte
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/admin/kategorien"
              className={({ isActive }) =>
                `flex items-center p-3 rounded-md ${
                  isActive
                    ? 'bg-gray-800 text-white'
                    : 'hover:bg-gray-800 hover:text-white'
                }`
              }
            >
              <FiTag className="mr-3" />
              Kategorien
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/admin/blog"
              className={({ isActive }) =>
                `flex items-center p-3 rounded-md ${
                  isActive
                    ? 'bg-gray-800 text-white'
                    : 'hover:bg-gray-800 hover:text-white'
                }`
              }
            >
              <FiFileText className="mr-3" />
              Blog
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/admin/benutzer"
              className={({ isActive }) =>
                `flex items-center p-3 rounded-md ${
                  isActive
                    ? 'bg-gray-800 text-white'
                    : 'hover:bg-gray-800 hover:text-white'
                }`
              }
            >
              <FiUsers className="mr-3" />
              Benutzer
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/admin/einstellungen"
              className={({ isActive }) =>
                `flex items-center p-3 rounded-md ${
                  isActive
                    ? 'bg-gray-800 text-white'
                    : 'hover:bg-gray-800 hover:text-white'
                }`
              }
            >
              <FiSettings className="mr-3" />
              Einstellungen
            </NavLink>
          </li>
        </ul>
      </nav>
    </aside>
  );
};

export default AdminSidebar;
