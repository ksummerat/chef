import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { FiMenu, FiUser, FiLogOut } from 'react-icons/fi';

const AdminHeader = () => {
  const [isProfileOpen, setIsProfileOpen] = React.useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const toggleProfile = () => {
    setIsProfileOpen(!isProfileOpen);
  };

  return (
    <header className="bg-gray-800 text-white">
      <div className="px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <button
            className="lg:hidden mr-3 text-gray-300 hover:text-white focus:outline-none"
            aria-label="Toggle sidebar"
          >
            <FiMenu className="w-6 h-6" />
          </button>
          <Link to="/admin" className="flex items-center">
            <span className="text-xl font-bold">Admin-Bereich</span>
          </Link>
        </div>

        <div className="relative">
          <button
            onClick={toggleProfile}
            className="flex items-center space-x-2 text-gray-300 hover:text-white focus:outline-none"
          >
            <FiUser className="w-5 h-5" />
            <span>{user?.name}</span>
          </button>
          {isProfileOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
              <Link
                to="/"
                className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
              >
                Zur Website
              </Link>
              <Link
                to="/profil"
                className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
              >
                Mein Profil
              </Link>
              <button
                onClick={handleLogout}
                className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
              >
                <div className="flex items-center">
                  <FiLogOut className="mr-2" />
                  Abmelden
                </div>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default AdminHeader;
