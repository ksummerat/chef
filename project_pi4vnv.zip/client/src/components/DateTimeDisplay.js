import React from 'react';

const DateTimeDisplay = ({ timestamp, className = '' }) => {
  const formatDate = (date) => {
    const options = { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    };
    return new Date(date).toLocaleDateString('de-DE', options);
  };

  return (
    <time dateTime={new Date(timestamp).toISOString()} className={className}>
      {formatDate(timestamp)}
    </time>
  );
};

export default DateTimeDisplay;
