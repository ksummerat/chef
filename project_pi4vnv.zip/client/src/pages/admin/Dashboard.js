import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { FiUsers, FiList, FiFileText, FiTag, FiActivity } from 'react-icons/fi';

const Dashboard = () => {
  const { authAxios } = useAuth();
  const [stats, setStats] = useState({
    users: 0,
    recipes: 0,
    categories: 0,
    blogPosts: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In einer vollständigen Implementierung würden hier echte API-Aufrufe stehen
    // Für jetzt verwenden wir Beispieldaten
    const fetchStats = async () => {
      try {
        // Simuliere API-Aufruf
        setTimeout(() => {
          setStats({
            users: 24,
            recipes: 156,
            categories: 12,
            blogPosts: 8
          });
          setLoading(false);
        }, 500);
      } catch (error) {
        console.error('Fehler beim Laden der Statistiken:', error);
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>

      {/* Statistik-Karten */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-primary-100 text-primary-600 mr-4">
              <FiUsers className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Benutzer</p>
              <p className="text-2xl font-bold">{stats.users}</p>
            </div>
          </div>
          <Link
            to="/admin/benutzer"
            className="text-sm text-primary-600 hover:text-primary-700 font-medium mt-4 inline-block"
          >
            Details anzeigen
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-secondary-100 text-secondary-600 mr-4">
              <FiList className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Rezepte</p>
              <p className="text-2xl font-bold">{stats.recipes}</p>
            </div>
          </div>
          <Link
            to="/admin/rezepte"
            className="text-sm text-primary-600 hover:text-primary-700 font-medium mt-4 inline-block"
          >
            Details anzeigen
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-accent-100 text-accent-600 mr-4">
              <FiTag className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Kategorien</p>
              <p className="text-2xl font-bold">{stats.categories}</p>
            </div>
          </div>
          <Link
            to="/admin/kategorien"
            className="text-sm text-primary-600 hover:text-primary-700 font-medium mt-4 inline-block"
          >
            Details anzeigen
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-green-100 text-green-600 mr-4">
              <FiFileText className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Blog-Beiträge</p>
              <p className="text-2xl font-bold">{stats.blogPosts}</p>
            </div>
          </div>
          <Link
            to="/admin/blog"
            className="text-sm text-primary-600 hover:text-primary-700 font-medium mt-4 inline-block"
          >
            Details anzeigen
          </Link>
        </div>
      </div>

      {/* Aktivitätsübersicht */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold">Letzte Aktivitäten</h2>
          <FiActivity className="text-gray-400" />
        </div>
        <div className="space-y-4">
          {/* Beispiel-Aktivitäten */}
          <div className="flex items-start pb-4 border-b border-gray-100">
            <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center mr-3 flex-shrink-0">
              <FiUsers className="text-primary-600" />
            </div>
            <div>
              <p className="font-medium">Neuer Benutzer registriert</p>
              <p className="text-sm text-gray-500">Max Mustermann hat sich registriert</p>
              <p className="text-xs text-gray-400 mt-1">Vor 2 Stunden</p>
            </div>
          </div>
          <div className="flex items-start pb-4 border-b border-gray-100">
            <div className="w-10 h-10 rounded-full bg-secondary-100 flex items-center justify-center mr-3 flex-shrink-0">
              <FiList className="text-secondary-600" />
            </div>
            <div>
              <p className="font-medium">Neues Rezept erstellt</p>
              <p className="text-sm text-gray-500">Schokoladenkuchen wurde hinzugefügt</p>
              <p className="text-xs text-gray-400 mt-1">Vor 5 Stunden</p>
            </div>
          </div>
          <div className="flex items-start pb-4 border-b border-gray-100">
            <div className="w-10 h-10 rounded-full bg-accent-100 flex items-center justify-center mr-3 flex-shrink-0">
              <FiTag className="text-accent-600" />
            </div>
            <div>
              <p className="font-medium">Kategorie aktualisiert</p>
              <p className="text-sm text-gray-500">Kategorie "Desserts" wurde aktualisiert</p>
              <p className="text-xs text-gray-400 mt-1">Vor 1 Tag</p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
              <FiFileText className="text-green-600" />
            </div>
            <div>
              <p className="font-medium">Blog-Beitrag veröffentlicht</p>
              <p className="text-sm text-gray-500">Neuer Beitrag "Kochtipps für Anfänger" veröffentlicht</p>
              <p className="text-xs text-gray-400 mt-1">Vor 2 Tagen</p>
            </div>
          </div>
        </div>
      </div>

      {/* Schnellzugriff */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-bold mb-4">Schnellzugriff</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link
            to="/admin/rezepte/neu"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
          >
            <div className="p-2 rounded-full bg-secondary-100 text-secondary-600 mr-3">
              <FiList className="w-5 h-5" />
            </div>
            <span>Neues Rezept erstellen</span>
          </Link>
          <Link
            to="/admin/kategorien/neu"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
          >
            <div className="p-2 rounded-full bg-accent-100 text-accent-600 mr-3">
              <FiTag className="w-5 h-5" />
            </div>
            <span>Neue Kategorie erstellen</span>
          </Link>
          <Link
            to="/admin/blog/neu"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
          >
            <div className="p-2 rounded-full bg-green-100 text-green-600 mr-3">
              <FiFileText className="w-5 h-5" />
            </div>
            <span>Neuen Blog-Beitrag erstellen</span>
          </Link>
          <Link
            to="/admin/benutzer"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
          >
            <div className="p-2 rounded-full bg-primary-100 text-primary-600 mr-3">
              <FiUsers className="w-5 h-5" />
            </div>
            <span>Benutzer verwalten</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
