import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { FiPlus, FiEdit2, FiTrash2, FiEye, FiSearch } from 'react-icons/fi';
import DateTimeDisplay from '../../components/DateTimeDisplay';

const BlogPosts = () => {
  const { authAxios } = useAuth();
  const [blogPosts, setBlogPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchBlogPosts = async () => {
      try {
        // In einer realen Anwendung würden diese Daten von der API kommen
        // Hier simulieren wir die Daten für Demonstrationszwecke
        setTimeout(() => {
          setBlogPosts([
            {
              id: 1,
              title: 'Die besten Kochtipps für Anfänger',
              slug: 'die-besten-kochtipps-fuer-anfaenger',
              excerpt: 'Lernen Sie die grundlegenden Techniken und Tipps, die jeder Anfänger in der Küche kennen sollte.',
              content: 'Lorem ipsum dolor sit amet...',
              author: {
                id: 1,
                name: 'Max Mustermann'
              },
              categories: ['Tipps & Tricks', 'Grundlagen'],
              published: true,
              createdAt: '2023-08-15T10:30:00Z',
              updatedAt: '2023-08-16T14:20:00Z'
            },
            {
              id: 2,
              title: 'Saisonale Zutaten im Herbst',
              slug: 'saisonale-zutaten-im-herbst',
              excerpt: 'Entdecken Sie die besten Zutaten, die im Herbst Saison haben und wie Sie diese in Ihren Rezepten verwenden können.',
              content: 'Lorem ipsum dolor sit amet...',
              author: {
                id: 2,
                name: 'Anna Schmidt'
              },
              categories: ['Saisonales', 'Zutaten'],
              published: true,
              createdAt: '2023-08-10T08:45:00Z',
              updatedAt: '2023-08-10T08:45:00Z'
            },
            {
              id: 3,
              title: 'Vegane Ernährung: Ein Leitfaden für Einsteiger',
              slug: 'vegane-ernaehrung-ein-leitfaden-fuer-einsteiger',
              excerpt: 'Alles, was Sie über den Einstieg in die vegane Ernährung wissen müssen, von Nährstoffen bis zu Ersatzprodukten.',
              content: 'Lorem ipsum dolor sit amet...',
              author: {
                id: 1,
                name: 'Max Mustermann'
              },
              categories: ['Vegan', 'Ernährung'],
              published: false,
              createdAt: '2023-08-05T16:20:00Z',
              updatedAt: '2023-08-07T11:30:00Z'
            },
            {
              id: 4,
              title: 'Die Kunst des Brotbackens',
              slug: 'die-kunst-des-brotbackens',
              excerpt: 'Von einfachen Rezepten bis hin zu Sauerteig - lernen Sie, wie Sie zu Hause perfektes Brot backen können.',
              content: 'Lorem ipsum dolor sit amet...',
              author: {
                id: 3,
                name: 'Julia Weber'
              },
              categories: ['Backen', 'Grundlagen'],
              published: true,
              createdAt: '2023-07-28T09:15:00Z',
              updatedAt: '2023-07-29T14:40:00Z'
            }
          ]);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Fehler beim Laden der Blog-Beiträge:', error);
        setLoading(false);
      }
    };

    fetchBlogPosts();
  }, [authAxios]);

  const handleDelete = async (id) => {
    if (window.confirm('Sind Sie sicher, dass Sie diesen Blog-Beitrag löschen möchten?')) {
      try {
        // Blog-Beitrag löschen (simuliert)
        setBlogPosts(blogPosts.filter(post => post.id !== id));
      } catch (error) {
        console.error('Fehler beim Löschen des Blog-Beitrags:', error);
      }
    }
  };

  const filteredBlogPosts = blogPosts.filter(post =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.author.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Blog-Beiträge verwalten</h2>
        <button className="btn btn-primary flex items-center">
          <FiPlus className="mr-2" /> Neuer Beitrag
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <FiSearch className="text-gray-400" />
          </div>
          <input
            type="text"
            className="input pl-10"
            placeholder="Blog-Beiträge durchsuchen..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Titel
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Autor
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Kategorien
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Datum
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Aktionen
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredBlogPosts.map((post) => (
              <tr key={post.id}>
                <td className="px-6 py-4">
                  <div className="text-sm font-medium text-gray-900">{post.title}</div>
                  <div className="text-sm text-gray-500 line-clamp-1">{post.excerpt}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{post.author.name}</div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-wrap gap-1">
                    {post.categories.map((category, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                      >
                        {category}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      post.published
                        ? 'bg-green-100 text-green-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}
                  >
                    {post.published ? 'Veröffentlicht' : 'Entwurf'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <DateTimeDisplay timestamp={post.updatedAt} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button className="text-indigo-600 hover:text-indigo-900 mr-3">
                    <FiEye className="inline" /> Ansehen
                  </button>
                  <button className="text-primary-600 hover:text-primary-900 mr-3">
                    <FiEdit2 className="inline" /> Bearbeiten
                  </button>
                  <button
                    onClick={() => handleDelete(post.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <FiTrash2 className="inline" /> Löschen
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default BlogPosts;
