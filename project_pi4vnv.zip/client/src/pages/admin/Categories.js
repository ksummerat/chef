import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';
import { FiPlus, FiEdit2, FiTrash2, FiX, FiCheck, FiAlertCircle } from 'react-icons/fi';

const Categories = () => {
  const { authAxios } = useAuth();
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    color: '#2F4F4F',
    icon: 'utensils'
  });

  // Beispiel-Icons für die Auswahl
  const availableIcons = ['utensils', 'coffee', 'pizza-slice', 'hamburger', 'ice-cream', 'bread-slice', 'cheese', 'egg', 'fish', 'apple-alt', 'carrot', 'lemon', 'pepper-hot', 'wine-glass-alt', 'beer', 'cocktail'];

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        // In einer realen Anwendung würden diese Daten von der API kommen
        // Hier simulieren wir die Daten für Demonstrationszwecke
        setTimeout(() => {
          setCategories([
            { id: 1, name: 'Hauptgerichte', slug: 'hauptgerichte', description: 'Herzhafte Hauptmahlzeiten', color: '#2F4F4F', icon: 'utensils', order: 1 },
            { id: 2, name: 'Desserts', slug: 'desserts', description: 'Süße Nachspeisen', color: '#C47B59', icon: 'ice-cream', order: 2 },
            { id: 3, name: 'Vorspeisen', slug: 'vorspeisen', description: 'Appetitanregende Starter', color: '#C9A569', icon: 'cheese', order: 3 },
            { id: 4, name: 'Getränke', slug: 'getranke', description: 'Erfrischende Getränke', color: '#4A90E2', icon: 'wine-glass-alt', order: 4 },
            { id: 5, name: 'Vegetarisch', slug: 'vegetarisch', description: 'Fleischlose Gerichte', color: '#50B83C', icon: 'carrot', order: 5 },
            { id: 6, name: 'Backen', slug: 'backen', description: 'Kuchen und Gebäck', color: '#9C6F44', icon: 'bread-slice', order: 6 }
          ]);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Fehler beim Laden der Kategorien:', error);
        setError('Kategorien konnten nicht geladen werden.');
        setLoading(false);
      }
    };

    fetchCategories();
  }, [authAxios]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      setError('Bitte geben Sie einen Kategorienamen ein.');
      return;
    }

    try {
      if (editingCategory) {
        // Kategorie aktualisieren (simuliert)
        setCategories(categories.map(cat => 
          cat.id === editingCategory.id 
            ? { ...cat, ...formData } 
            : cat
        ));
        setSuccess('Kategorie erfolgreich aktualisiert.');
      } else {
        // Neue Kategorie erstellen (simuliert)
        const newCategory = {
          id: Date.now(),
          ...formData,
          slug: formData.name.toLowerCase().replace(/\s+/g, '-'),
          order: categories.length + 1
        };
        setCategories([...categories, newCategory]);
        setSuccess('Kategorie erfolgreich erstellt.');
      }
      
      resetForm();
    } catch (error) {
      console.error('Fehler beim Speichern der Kategorie:', error);
      setError('Kategorie konnte nicht gespeichert werden.');
    }
  };

  const handleEdit = (category) => {
    setEditingCategory(category);
    setFormData({
      name: category.name,
      description: category.description,
      color: category.color,
      icon: category.icon
    });
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Sind Sie sicher, dass Sie diese Kategorie löschen möchten?')) {
      try {
        // Kategorie löschen (simuliert)
        setCategories(categories.filter(cat => cat.id !== id));
        setSuccess('Kategorie erfolgreich gelöscht.');
      } catch (error) {
        console.error('Fehler beim Löschen der Kategorie:', error);
        setError('Kategorie konnte nicht gelöscht werden.');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      color: '#2F4F4F',
      icon: 'utensils'
    });
    setEditingCategory(null);
    setShowForm(false);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Kategorien verwalten</h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="btn btn-primary flex items-center"
        >
          {showForm ? (
            <>
              <FiX className="mr-2" /> Abbrechen
            </>
          ) : (
            <>
              <FiPlus className="mr-2" /> Neue Kategorie
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="bg-red-50 text-red-700 p-4 rounded-md mb-6 flex items-start">
          <FiAlertCircle className="mr-2 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="bg-green-50 text-green-700 p-4 rounded-md mb-6 flex items-start">
          <FiCheck className="mr-2 mt-0.5 flex-shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {showForm && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="bg-white rounded-lg shadow-sm p-6 mb-8 overflow-hidden"
        >
          <h3 className="text-xl font-bold mb-4">
            {editingCategory ? 'Kategorie bearbeiten' : 'Neue Kategorie erstellen'}
          </h3>
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="label">Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="input"
                  required
                />
              </div>
              <div>
                <label htmlFor="color" className="label">Farbe</label>
                <div className="flex items-center">
                  <input
                    type="color"
                    id="color"
                    name="color"
                    value={formData.color}
                    onChange={handleChange}
                    className="h-10 w-10 rounded border border-gray-300 mr-2"
                  />
                  <input
                    type="text"
                    value={formData.color}
                    onChange={handleChange}
                    name="color"
                    className="input flex-grow"
                  />
                </div>
              </div>
              <div className="md:col-span-2">
                <label htmlFor="description" className="label">Beschreibung</label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  className="input h-24"
                ></textarea>
              </div>
              <div className="md:col-span-2">
                <label className="label">Icon</label>
                <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                  {availableIcons.map(icon => (
                    <button
                      key={icon}
                      type="button"
                      className={`p-3 rounded-md border ${
                        formData.icon === icon
                          ? 'border-primary-600 bg-primary-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => setFormData({ ...formData, icon })}
                    >
                      <i className={`fas fa-${icon} text-lg ${
                        formData.icon === icon ? 'text-primary-600' : 'text-gray-600'
                      }`}></i>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-end mt-6 space-x-3">
              <button
                type="button"
                onClick={resetForm}
                className="btn btn-outline"
              >
                Abbrechen
              </button>
              <button
                type="submit"
                className="btn btn-primary"
              >
                {editingCategory ? 'Aktualisieren' : 'Erstellen'}
              </button>
            </div>
          </form>
        </motion.div>
      )}

      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Name
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Beschreibung
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Farbe
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Icon
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Aktionen
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {categories.map((category) => (
              <tr key={category.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="h-4 w-4 rounded-full mr-2" style={{ backgroundColor: category.color }}></div>
                    <div className="text-sm font-medium text-gray-900">{category.name}</div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm text-gray-500 line-clamp-2">{category.description}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">{category.color}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">
                    <i className={`fas fa-${category.icon} text-lg`} style={{ color: category.color }}></i>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    onClick={() => handleEdit(category)}
                    className="text-primary-600 hover:text-primary-900 mr-3"
                  >
                    <FiEdit2 className="inline" /> Bearbeiten
                  </button>
                  <button
                    onClick={() => handleDelete(category.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <FiTrash2 className="inline" /> Löschen
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Categories;
