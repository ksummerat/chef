import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';
import { FiUserPlus, FiEdit2, FiTrash2, FiCheck, FiX, FiAlertCircle, FiShield, FiUser } from 'react-icons/fi';

const Users = () => {
  const { authAxios } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        // In einer realen Anwendung würden diese Daten von der API kommen
        // Hier simulieren wir die Daten für Demonstrationszwecke
        setTimeout(() => {
          setUsers([
            {
              id: 1,
              name: 'Admin',
              email: 'admin@example.com',
              role: 'admin',
              profileImage: 'https://randomuser.me/api/portraits/men/1.jpg',
              createdAt: '2023-01-15T10:30:00Z'
            },
            {
              id: 2,
              name: 'Max Mustermann',
              email: 'max@example.com',
              role: 'user',
              profileImage: 'https://randomuser.me/api/portraits/men/2.jpg',
              createdAt: '2023-04-20T14:45:00Z'
            },
            {
              id: 3,
              name: 'Maria Schmidt',
              email: 'maria@example.com',
              role: 'user',
              profileImage: 'https://randomuser.me/api/portraits/women/3.jpg',
              createdAt: '2023-05-05T09:15:00Z'
            },
            {
              id: 4,
              name: 'Thomas Müller',
              email: 'thomas@example.com',
              role: 'user',
              profileImage: 'https://randomuser.me/api/portraits/men/4.jpg',
              createdAt: '2023-05-10T16:20:00Z'
            }
          ]);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Fehler beim Laden der Benutzer:', error);
        setError('Benutzer konnten nicht geladen werden.');
        setLoading(false);
      }
    };

    fetchUsers();
  }, [authAxios]);

  const handleToggleRole = async (id, currentRole) => {
    try {
      // Benutzerrolle ändern (simuliert)
      setUsers(users.map(user => 
        user.id === id 
          ? { ...user, role: currentRole === 'admin' ? 'user' : 'admin' } 
          : user
      ));
      setSuccess('Benutzerrolle erfolgreich geändert.');
    } catch (error) {
      console.error('Fehler beim Ändern der Benutzerrolle:', error);
      setError('Benutzerrolle konnte nicht geändert werden.');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Sind Sie sicher, dass Sie diesen Benutzer löschen möchten?')) {
      try {
        // Benutzer löschen (simuliert)
        setUsers(users.filter(user => user.id !== id));
        setSuccess('Benutzer erfolgreich gelöscht.');
      } catch (error) {
        console.error('Fehler beim Löschen des Benutzers:', error);
        setError('Benutzer konnte nicht gelöscht werden.');
      }
    }
  };

  const formatDate = (dateString) => {
    const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
    return new Date(dateString).toLocaleDateString('de-DE', options);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Benutzer verwalten</h2>
        <button className="btn btn-primary flex items-center">
          <FiUserPlus className="mr-2" /> Neuer Benutzer
        </button>
      </div>

      {error && (
        <div className="bg-red-50 text-red-700 p-4 rounded-md mb-6 flex items-start">
          <FiAlertCircle className="mr-2 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="bg-green-50 text-green-700 p-4 rounded-md mb-6 flex items-start">
          <FiCheck className="mr-2 mt-0.5 flex-shrink-0" />
          <span>{success}</span>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Benutzer
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                E-Mail
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Rolle
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Registriert am
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Aktionen
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {users.map((user) => (
              <tr key={user.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10">
                      <img 
                        className="h-10 w-10 rounded-full object-cover" 
                        src={user.profileImage} 
                        alt={user.name}
                        onError={(e) => {
                          e.target.src = 'https://via.placeholder.com/40';
                        }}
                      />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">{user.name}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">{user.email}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    user.role === 'admin' 
                      ? 'bg-primary-100 text-primary-800' 
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {user.role === 'admin' ? (
                      <>
                        <FiShield className="mr-1" /> Admin
                      </>
                    ) : (
                      <>
                        <FiUser className="mr-1" /> Benutzer
                      </>
                    )}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">{formatDate(user.createdAt)}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    onClick={() => handleToggleRole(user.id, user.role)}
                    className={`${
                      user.role === 'admin' 
                        ? 'text-gray-600 hover:text-gray-900' 
                        : 'text-primary-600 hover:text-primary-900'
                    } mr-3`}
                  >
                    {user.role === 'admin' ? (
                      <>
                        <FiUser className="inline" /> Zum Benutzer machen
                      </>
                    ) : (
                      <>
                        <FiShield className="inline" /> Zum Admin machen
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => handleDelete(user.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <FiTrash2 className="inline" /> Löschen
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Users;
