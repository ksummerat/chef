import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const Home = () => {
  const [featuredRecipes, setFeaturedRecipes] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // In einer vollständigen Implementierung würden hier echte API-Aufrufe stehen
        // Für jetzt verwenden wir Beispieldaten
        
        // Beispiel-Kategorien
        setCategories([
          { _id: '1', name: 'Hauptgerichte', slug: 'hauptgerichte', image: 'no-image.jpg' },
          { _id: '2', name: 'Desserts', slug: 'desserts', image: 'no-image.jpg' },
          { _id: '3', name: 'Vegetarisch', slug: 'vegetarisch', image: 'no-image.jpg' },
          { _id: '4', name: 'Vegan', slug: 'vegan', image: 'no-image.jpg' }
        ]);
        
        // Beispiel-Rezepte
        setFeaturedRecipes([
          { 
            _id: '1', 
            title: 'Spaghetti Bolognese', 
            description: 'Ein klassisches italienisches Gericht mit herzhafter Fleischsauce.',
            image: 'no-image.jpg',
            prepTime: 15,
            cookTime: 45,
            difficulty: 'Einfach'
          },
          { 
            _id: '2', 
            title: 'Schokoladenkuchen', 
            description: 'Saftiger Schokoladenkuchen mit cremiger Ganache.',
            image: 'no-image.jpg',
            prepTime: 20,
            cookTime: 35,
            difficulty: 'Mittel'
          },
          { 
            _id: '3', 
            title: 'Gemüsecurry', 
            description: 'Würziges Curry mit saisonalem Gemüse und Kokosmilch.',
            image: 'no-image.jpg',
            prepTime: 15,
            cookTime: 25,
            difficulty: 'Einfach'
          }
        ]);
        
        setLoading(false);
      } catch (error) {
        console.error('Fehler beim Laden der Daten:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div>
      {/* Hero-Bereich */}
      <section className="bg-gradient-to-r from-primary-600 to-primary-800 text-white rounded-lg p-8 mb-12">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Entdecken Sie köstliche Rezepte
          </h1>
          <p className="text-xl mb-8">
            Finden Sie Inspiration für Ihre nächste Mahlzeit und teilen Sie Ihre eigenen Kreationen.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/rezepte" className="btn bg-white text-primary-700 hover:bg-gray-100">
              Rezepte entdecken
            </Link>
            <Link to="/registrieren" className="btn bg-primary-700 text-white hover:bg-primary-800 border border-white">
              Jetzt registrieren
            </Link>
          </div>
        </div>
      </section>

      {/* Kategorien */}
      <section className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Kategorien</h2>
          <Link to="/kategorien" className="text-primary-600 hover:text-primary-700">
            Alle anzeigen
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categories.map((category) => (
            <Link
              key={category._id}
              to={`/kategorien/${category.slug}`}
              className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
            >
              <div className="aspect-w-16 aspect-h-9 bg-gray-200">
                {/* Hier würde ein Bild angezeigt werden */}
                <div className="flex items-center justify-center h-32 bg-gray-200 text-gray-500">
                  Bild
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-medium text-lg">{category.name}</h3>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Empfohlene Rezepte */}
      <section className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Empfohlene Rezepte</h2>
          <Link to="/rezepte" className="text-primary-600 hover:text-primary-700">
            Alle anzeigen
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredRecipes.map((recipe) => (
            <div
              key={recipe._id}
              className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
            >
              <div className="aspect-w-16 aspect-h-9 bg-gray-200">
                {/* Hier würde ein Bild angezeigt werden */}
                <div className="flex items-center justify-center h-48 bg-gray-200 text-gray-500">
                  Rezeptbild
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-lg mb-2">{recipe.title}</h3>
                <p className="text-gray-600 mb-4">{recipe.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">
                    {recipe.prepTime + recipe.cookTime} Min.
                  </span>
                  <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">
                    {recipe.difficulty}
                  </span>
                </div>
                <Link
                  to={`/rezepte/${recipe._id}`}
                  className="text-primary-600 hover:text-primary-700 font-medium"
                >
                  Zum Rezept
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA-Bereich */}
      <section className="bg-secondary-100 rounded-lg p-8 text-center">
        <h2 className="text-2xl font-bold mb-4">Teilen Sie Ihre Lieblingsrezepte</h2>
        <p className="text-lg mb-6 max-w-2xl mx-auto">
          Werden Sie Teil unserer Community und teilen Sie Ihre kulinarischen Kreationen mit anderen Kochbegeisterten.
        </p>
        <Link to="/registrieren" className="btn btn-primary">
          Jetzt mitmachen
        </Link>
      </section>
    </div>
  );
};

export default Home;
